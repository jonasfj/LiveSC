package edu.wis.jtlv.env.core.smv.eval;

public interface ILTLOperator {

}

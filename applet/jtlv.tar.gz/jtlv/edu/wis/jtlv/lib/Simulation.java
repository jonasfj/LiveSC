package edu.wis.jtlv.lib;

/**
 * <p>
 * Simulation - NOT YET IMPLEMENTED.
 * </p>
 * 
 * <p>
 * Seems like should be considered as an eclipse debugger for SMV files.
 * </p>
 * 
 * @version {@value edu.wis.jtlv.env.Env#version}
 * @author yaniv sa'ar.
 * 
 */
public class Simulation {

}
